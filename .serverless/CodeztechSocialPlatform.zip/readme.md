# Installation Details #

1. NodeJS into your system (nvm)
2. Package.json needs to create - npm init
3. npm install (make sure you are using node version - 8.9.4)
4. Use nvm to make a switch of node version
5. run the app - node local.js


# NodeJS #

NodeJS - 

1. Version - 8.9.4

# Database #

Mongodb Cloud